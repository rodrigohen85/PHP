<?php
    $servers = array(

        'Roteador TP-Link' => array(
            'ip' => '192.168.15.1',
            'port' => 80,
            'info' => 'Roteador Principal',
        ),

        'Servidor 01' => array(
            'ip' => '192.168.15.10',
            'port' => 139,
            'info' => 'Servidor Principal',
        ),

        'Servidor 02' => array(
            'ip' => '192.168.15.5',
            'port' => 139,
            'info' => 'Servidor Secundario',
        ),

        'XAmbienteTeste' => array(
            'ip' => '192.168.15.100',
            'port' => 22,
            'info' => 'Ambiente de Testes',
        )
    
    );

?>

